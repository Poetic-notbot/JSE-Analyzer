# Jamaican Stock Financial Statement Analyzer

A Streamlit app for analysing companies listed on the Jamaica Stock Exchange (JSE).

Pick a company and drill into **any** line item on its Income Statement, Balance
Sheet or Cash Flow Statement to see:

- how the item has changed over the last several years (trend),
- its year-over-year growth,
- its share of the relevant total (e.g. a balance-sheet item as a % of Total
  Assets) — so you can see the *makeup* of the company and how it is shifting,
- a plain-language read of **what** changed and, for subtotals like "Total
  Assets", **which** underlying components drove the change,
- the ratios the item feeds into, and
- a simple valuation (2-stage DCF + an earnings-multiple cross-check).

The goal: understand the true makeup of a company, what has changed and how,
the results those changes delivered, and what that suggests about past decisions
and the road ahead.

## Run it

```bash
pip install -r requirements.txt
streamlit run app.py
```

Then open the local URL Streamlit prints (usually http://localhost:8501).

## Where the data comes from

Figures are read live from stockanalysis.com. Note that the site was rebuilt
since the original 2025 version of this tool: it no longer exposes plain HTML
tables, so this version reads the structured JSON feed behind each financials
page (the `/__data.json` endpoint) instead. That is more reliable and gives the
full set of line items plus the subtotal markers used for the drill-down.

USD-reporting companies are labelled `USD`; their per-share and valuation
figures are shown in their reported currency rather than converted, to avoid a
hard-coded exchange rate.

## Ideas to improve next

- Convert USD reporters to JMD using a live FX rate.
- Add a sector/peer comparison view.
- Add a reverse-DCF ("what growth is the current price assuming?").
- Cache fetched data to disk so repeat runs are instant and offline-capable.
- Tighten income-statement subtotal tagging (margin rows are currently treated
  as subtotals for the component walk; harmless but improvable).
